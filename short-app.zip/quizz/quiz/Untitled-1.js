class="classUserProfilclick" data-id="' . $row['id'] . '"

<script>

    function fetchUserData(userId) {
                // AJAX request to fetch data from the server
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        // Handle the response and update the UI
                        document.getElementById("userDetails").innerHTML = this.responseText;
                    }
                };
                xhr.open("GET", "get_user_data.php?userId=" + userId, true);
                xhr.send();}
    
    
    $(document).ready(function() {
        // Attach click event to elements with class 'classUserProfilclick'
        $('.classUserProfilclick').click(function() {
          console.log("clicked");
            // Get the data-id attribute value
            var userId = $(this).data('id');
            
            // Navigate to url.php with the user's ID as a parameter
            window.location.href = 'user_profile.php?user=' + userId;
        });
    });
    
    
</script>    