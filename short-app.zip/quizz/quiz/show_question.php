<?php
include 'config.php';


?>



<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Test Exam</title>

        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">

        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;300;400;700;900&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link rel="stylesheet" href="css/slick.css"/>

        <link href="css/tooplate-little-fashion.css" rel="stylesheet">
        
<style>
 /* #main {
        background-image: url("./images/bg.jpg");
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        opacity:0.7;
      } */


      body{
    background: linear-gradient(to left, #58D68D, #90EEEE);
   }
.cut:hover { Insert the result into the 'answer' table
    background-color: #e0f7e9;
    color: green;
    border: 2px solid darkgreen;
    font-weight: bold; /* makes text bold */
}


.cut:hover {
    background-color: #e0f7e9;
    color: green;
    border: 2px solid darkgreen;
    cursor: pointer; /* changes cursor to pointer */
}
</style>
    </head>
    
    <body id='main'>
<!-- 
        <section class="preloader">
            <div class="spinner">
                <span class="sk-inner-circle"></span>
            </div>
        </section> -->
    
        <main>

        <nav class="navbar navbar-expand-lg">
        <div class="container">
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>

          <a class="navbar-brand" href="index.html">
            <strong><span class="text-success">Biology Test </span>Exam</strong>
          </a>

          <div class="d-lg-none">
            <a href="sign-in.php" class="bi-person custom-icon me-3"></a>

      
          </div>

          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item">
                <a class="nav-link active" href="index.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="about.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="products.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="faq.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="contact.html"></a>
              </li>
            </ul>

            <div class="d-none d-lg-block">
              <a href="sign-in.php" class="bi-person custom-icon me-3"></a>

              <!-- <a href="" class="bi-bag custom-icon"></a> -->
            </div>
          </div>
        </div>
      </nav>
    
      <div class="wapper">
            <div class="container container-bg-set pb-4 mt-5">
          
                <div class="shadow-box top-margin ">
                
                <div class="card text-center mt-5">

  <div class="card-body mt-5">
  <section class="sign-in-form section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-8 mx-auto col-12">

                            <h3 class="hero-title text-center mb-5">Attempt the Question Below</h3>

                            <div class="row">
                                <div class="col-lg-8 col-11 mx-auto">
                                <?php

include 'config.php';


if (isset($_GET['question_id']) && !empty($_GET['question_id'])) {
 
  $id = $_GET['question_id'];

  
    $sql = "SELECT * FROM question WHERE id = '$id'"; 

    $result = mysqli_query($conn, $sql);

 
    if (mysqli_num_rows($result) > 0) {
  
        $row = mysqli_fetch_assoc($result);
    } else {
 
        echo "No question found for the given ID.";
        exit();
    }
} else {
   
    echo "Please provide a question ID.";
    exit();
}
?>

<!-- HTML form to display the question and input the answer -->

<form action="submit_ans.php" method="POST">
    <div class="form-floating mb-4 p-0">
        <input type="hidden" name="question_id" value="<?php echo htmlspecialchars($row['id']); ?>">
        <input type="text" name="question" id="question" class="form-control" value="<?php echo htmlspecialchars($row['question']); ?>" placeholder="Question" readonly>
        <label for="question">Question</label>
    </div>

    <div class="form-floating p-0">
        <textarea class="form-control" placeholder="Leave a comment here" name="answer" id="floatingTextarea" required></textarea>
        <label for="floatingTextarea">Answer</label>
    </div>
    
  
    <?php if($row['id'] != 10):?>

    <input type="submit" name="submit_answer" class="btn btn-info cut fw-bold  btn-lg rounded-pill form-control mt-4 mb-3" value="Next">

    <?php endif; ?>

    <?php if($row['id'] == 10): ?>
        <button class="btn btn-info cut fw-bold  btn-lg rounded-pill form-control mt-4 mb-3">
            <a href="result.php? id=<?php echo $row['id'] ?>" >Show Result</a>
        </button>
    <?php endif; ?>
</form>

                                    
                                </div>
                            </div>
                            
                        </div>

                    </div>
                </div>
            </section>

  </div>
  
</div>

                
                  
                </div>
            </div>  
        </div>
            
  </div>

            
        </main>

       

        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/Headroom.js"></script>
        <script src="js/jQuery.headroom.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/custom.js"></script>

    </body>
</html>
