<?php
include 'config.php'; // Ensure this file contains your database connection settings

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $question_id = mysqli_real_escape_string($conn, $_POST['question_id']);
    $user_answer = mysqli_real_escape_string($conn, $_POST['answer']);

    // Fetch the correct answer from the question table
    $sql = "SELECT answer FROM question WHERE id = '$question_id'";
    
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $correct_answer = $row['answer'];

        
        // Normalize both answers for comparison
        $user_answer = trim($user_answer);
        $correct_answer = trim($correct_answer);
      
        // Perform a case-insensitive comparison
        $is_correct = (strcasecmp($user_answer, $correct_answer) === 0) ? 1 : 0;
        // var_dump($is_correct);exit();
        // Insert the result into the answer table
        $sql_insert = "INSERT INTO answer (question_id, answer, result) VALUES ('$question_id', '$user_answer', '$is_correct')";

        if (mysqli_query($conn, $sql_insert)) {
            echo "Answer submitted successfully!";
            // Redirect to another page if needed
            header("Location: test.php");
            exit();
        } else {
            echo "Error: " . $sql_insert . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "No question found with the given ID.";
    }
} else {
    echo "Invalid request method.";
}
?>
