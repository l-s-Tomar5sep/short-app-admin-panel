<?php
$conn = mysqli_connect("localhost","root","9^9q|Tizs","exam");



// if($conn){
//     echo "Data is running";
// }else{
//     echo 'not running';
// }
?>