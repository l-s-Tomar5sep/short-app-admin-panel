
<?php
include 'config.php';

// Assuming $conn is your MySQLi connection object

$sql = "SELECT id, question FROM question LIMIT 10";
$result = mysqli_query($conn, $sql);

$rows = array(); // Initialize an array to store rows

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row; // Add each row to the $rows array
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Question and Submit</title>
    <!-- Include Bootstrap CSS for styling -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <div class="form-group">
        <!-- Buttons to represent questions -->
        <?php foreach ($rows as $row): ?>
            <button type="button" class="btn btn-info classUserProfilclick my-2" data-id="<?php echo $row['id']; ?>" data-question="<?php echo htmlspecialchars($row['question']); ?>">
                Question <?php echo $row['id']; ?>
            </button>
        <?php endforeach; ?>
    </div>
</div>

<!-- Include Bootstrap JS and dependencies -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>

<script>
// JavaScript to handle button click and disable button after first click
$(document).ready(function(){
    $('.classUserProfilclick').on('click', function(){
        var questionId = $(this).data('id');
        var questionText = $(this).data('question');
        
        // Disable the clicked button
        $(this).prop('disabled', true);

        // You can optionally perform other actions here, such as displaying the question text
        console.log('Question ID:', questionId);
        console.log('Question Text:', questionText);
        
        // Example: Redirect to show_question.php with question_id as a query parameter
        window.location.href = '?question_id=' + questionId;
    });
});
</script>

</body>
</html>
