<?php
include 'config.php';

if (isset($_GET['userId'])) {
    $userId = intval($_GET['userId']);
    
    $sql = "SELECT questions FROM questions WHERE id = $userId";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo $row['questions'];
    } else {
        echo "No question found.";
    }
} else {
    echo "Invalid request.";
}
?>
