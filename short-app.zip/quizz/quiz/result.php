<?php
include 'config.php';



?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Test Exam</title>

        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">

        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;300;400;700;900&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link rel="stylesheet" href="css/slick.css"/>

        <link href="css/tooplate-little-fashion.css" rel="stylesheet">
        
        <style>
          body{
    background: linear-gradient(to left, #58D68D, #90EEEE);
   }
    </style>
    </head>
    
    <body>

        
    
        <main>

        <nav class="navbar navbar-expand-lg">
        <div class="container">
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>

          <a class="navbar-brand" href="index.html">
            <strong><span class="text-center">Biology Test</span>Exam</strong>
          </a>

          <div class="d-lg-none">
            <a href="sign-in.php" class="bi-person custom-icon me-3"></a>

      
          </div>

          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item">
                <a class="nav-link active" href="index.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="about.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="products.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="faq.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="contact.html"></a>
              </li>
            </ul>

            <div class="d-none d-lg-block">
              <a href="sign-in.php" class="bi-person custom-icon me-3"></a>

              <!-- <a href="" class="bi-bag custom-icon"></a> -->
            </div>
          </div>
        </div>
      </nav>

        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Justify Answer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">


      <form role="form" action="<?php $_SERVER['PHP_SELF']?>" method="POST">
      <p id="modalQuestionId">Question ID: <span id="questionId"></span></p>
      <?php
include 'config.php';
if(isset($_GET['id'])){
$id = $_GET['id'];
$sql = "SELECT * FROM question  where id = $id";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
?>               
     


<div class="form-floating mb-4 p-0">
    <input type="text" name="username" id="email" value="<?php echo $row["answer"]?>" class="form-control" placeholder="Email address" required>

    <label for="email">Correct Answer</label>
</div>

<?php
    }
}
}
?>



<!-- 
<p class="text-center">Don’t have an account? <a href="sign-up.html">Create One</a></p> -->

</form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

            <section class="sign-in-form section-padding">
                <div class="container">
                    <div class="row">
                    <h2 class="hero-title text-center mb-5">Result</h2>
                      <div class="col-md-2 mt-4">
                     

                      <ul class="list-group">
                      <?php
include 'config.php';
$sql = "SELECT * FROM question  limit 1";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
?>               
        <li class="list-group-item">
            <button type="button" class="btn btn-info classUserProfilclick " data-id=" <?php echo $row['id']; ?>" data-toggle="tab" href="#menu">
                Result
            </button>
        </li>
<?php
    }
}
?>
</ul>
                      </div> 

                      <div class="col-md-8 ">
                      <div class="tab-content mt-3">
            <div id="menu" class="container tab-pane fade">

           

                                  
            <form role="form" action="show_question.php" method="POST">
<div class="row">



<?php



$sql = "SELECT * from answer limit 10";
$resu = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($resu)) {
?>
<div class="col-md-12 my-3">
<input type="text" class="form-control" value="Question <?php echo $row['question_id']; ?> &nbsp; <?php echo ($row['result'] == 0) ? 'Incorrect' : 'Correct'; ?>" readonly>
<?php if ($row['result'] == 0): ?>
    <button type="button" class="btn btn-warning mt-2 justify-bClosen" data-bs-toggle="modal" data-bs-target="#exampleModal" data-question-id="<?php echo $row['question_id']; ?>">Justify</button>
        <?php endif; ?>

</div>






<?php
    }
    
    
}

?>




<!-- Modal -->




</div>
</form>
            </div>
        </div>
         

            
                      </div> 

    <!------- ans write code-------->
                                
          
                            
                      

                    </div>
                </div>
            </section>

        </main>

        

     
<script>
    function fetchUserData(userId) {
        // AJAX request to fetch data from the server
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Handle the response and update the UI
                document.getElementById("question").value = this.responseText;
            }
        };
        xhr.open("GET", "que_data.php?userId=" + userId, true);
        xhr.send();
    }

    $(document).ready(function() {
        // Attach click event to elements with class 'classUserProfilclick'
        $('.classUserProfilclick').click(function() {
            console.log("clicked");
            // Get the data-id attribute value
            var userId = $(this).data('id');
            
            // Fetch user data and update the input field
            fetchUserData(userId);
        });
    });
</script>


        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/Headroom.js"></script>
        <script src="js/jQuery.headroom.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/custom.js"></script>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
$(document).ready(function(){
    // When the Justify button is clicked
    $('.justify-btn').on('click', function(){
        // Get the question ID from the button's data attribute
        var questionId = $(this).data('question-id');
        // Set the question ID in the modal
        $('#questionId').text(questionId);
    });
});
</script>

    </body>
</html>
