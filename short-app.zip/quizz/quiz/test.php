<?php
include 'config.php';

// Assuming $conn is your MySQLi connection object

$sql = "SELECT id, question FROM question LIMIT 10";
$result = mysqli_query($conn, $sql);

$rows = array(); // Initialize an array to store rows

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row; // Add each row to the $rows array
    }
}
?>


<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Biology test Exam</title>

        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">

        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;300;400;700;900&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link rel="stylesheet" href="css/slick.css"/>

        <link href="css/tooplate-little-fashion.css" rel="stylesheet">
        
        <style>
   body
   {
    background: linear-gradient(to right,#82E0AA , #90EEEE);
   }

.classUserProfilclick {
    background-color: orange;
    color: white;
    padding: 10px 20px;
    border: none;
    cursor: pointer;
}


.disabled-btn {
    background-color: lightgray !important;
    color: darkgray !important;
    border: 2px solid darkgray !important;
    cursor: not-allowed !important;
}

    </style>
    </head>
    
    <body>

        <!-- <section class="preloader">
            <div class="spinner">
                <span class="sk-inner-circle"></span>
            </div>
        </section> -->
    
        <main>

        <nav class="navbar navbar-expand-lg">
        <div class="container">
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>

          <a class="navbar-brand" href="index.html">
            <strong><span class="text-success">Biology Test</span>Exam</strong>
          </a>

          <div class="d-lg-none">
            <a href="sign-in.php" class="bi-person custom-icon me-3"></a>

      
          </div>

          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item">
                <a class="nav-link active" href="index.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="about.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="products.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="faq.html"></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="contact.html"></a>
              </li>
            </ul>

            <div class="d-none d-lg-block">
              <a href="sign-in.php" class="bi-person custom-icon me-3"></a>

              <!-- <a href="" class="bi-bag custom-icon"></a> -->
            </div>
          </div>
        </div>
      </nav>

            <section class="sign-in-form section-padding">
                <div class="container">
                    <div class="row">
                    <h3 class="hero-title text-center mb-5">Attempt the Question Below</h3>
         
         <div class="col-md-2">
         <ul class="list-group">
  <li class="list-group-item">
  <div class="form-group">
        <!-- Buttons to represent questions -->
        <form id="questionForm" action="show_question.php" method="POST">
        <div class="form-group">
            <!-- Buttons to represent questions -->
            <?php foreach ($rows as $row): ?>
                <button type="button" class="btn btn-success classUserProfilclick my-2" data-id="<?php echo $row['id']; ?>" data-question="<?php echo htmlspecialchars($row['question']); ?>">
                    Question <?php echo $row['id']; ?>
                </button>
                <input type="hidden" name="answered_questions[]" value="<?php echo $row['id']; ?>">
            <?php endforeach; ?>
        </div>
        <button type="submit" id="submitBtn" class="btn btn-primary" style="display: none;">Submit Answers</button>
    </form>
    </div>
  </li>

</ul>
         </div>

                                
          
            
         <div class="col-md-10">
         <div class="card-body">
            <!-- <h5 class="card-title">Selected Question</h5> -->
            <p class="card-text text-primary fw-bold" id="questionText"></p>


        </div>
         </div>                 
                      

                    </div>
                </div>
            </section>

        </main>

        

     
<script>
    function fetchUserData(userId) {
        // AJAX request to fetch data from the server
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Handle the response and update the UI
                document.getElementById("question").value = this.responseText;
            }
        };   $id = mysqli_real_escape_string($conn, $_GET['id']);
        xhr.open("GET", "que_data.php?userId=" + userId, true);
        xhr.send();
    }

    $(document).ready(function() {
        // Attach click event to elements with class 'classUserProfilclick'
        $('.classUserProfilclick').click(function() {
            console.log("clicked");
            // Get the data-id attribute value
            var userId = $(this).data('id');
            
            // Fetch user data and update the input field
            fetchUserData(userId);
        });
    });
</script>


        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/Headroom.js"></script>
        <script src="js/jQuery.headroom.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/custom.js"></script>
      
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>

<script>
// JavaScript to handle button click and update question display
$(document).ready(function(){
    $('.classUserProfilclick').on('click', function(){
        var questionId = $(this).data('id');
        var questionText = $(this).data('question');
        
        // Update the question text display
        $('#questionText').text(questionText);
    });
});
</script>
<script>
// JavaScript to handle button click and disable button after first click
$(document).ready(function(){
    $('.classUserProfilclick').on('click', function(){
        var questionId = $(this).data('id');
        var questionText = $(this).data('question');
        
        // Disable the clicked button
        $(this).prop('disabled', true);

        // You can optionally perform other actions here, such as displaying the question text
        console.log('Question ID:', questionId);
        console.log('Question Text:', questionText);
        
        // // Example: Redirect to show_question.php with question_id as a query parameter
        window.location.href = 'show_question.php?question_id=' + questionId;
    });
});
</script>

<script>
        // Example function that could cause auto-refresh
        function autoRefresh() {
            location.reload();
        }

        // Set an interval to auto-refresh every 5 seconds
        const intervalId = setInterval(autoRefresh, 100000);

        // Function to stop the auto-refresh
        function stopAutoRefresh() {
            clearInterval(intervalId); // This stops the interval and hence the auto-refresh
            console.log('Auto-refresh stopped');
        }

        // Stop the auto-refresh after 10 seconds
        setTimeout(stopAutoRefresh, 100000);
    </script>

    </body>
</html>
