
<?php
include 'config.php';

// Assuming $conn is your MySQLi connection object

$sql = "SELECT id, question FROM question LIMIT 10";
$result = mysqli_query($conn, $sql);

$rows = array(); // Initialize an array to store rows

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row; // Add each row to the $rows array
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Input Fields Example</title>
    <!-- Include Bootstrap CSS for styling -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <div class="form-group">
        <!-- Buttons to represent questions -->
        <?php foreach ($rows as $row): ?>
            <button type="button" class="btn btn-info classUserProfilclick" data-id="<?php echo $row['id']; ?>" data-question="<?php echo htmlspecialchars($row['question']); ?>">
                Question <?php echo $row['id']; ?>
            </button>
        <?php endforeach; ?>
    </div>

    <!-- Display area for the selected question -->
    <div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title">Selected Question</h5>
            <p class="card-text" id="questionText"></p>
        </div>
    </div>
</div>

<!-- Include Bootstrap JS and dependencies -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>

<script>
// JavaScript to handle button click and update question display
$(document).ready(function(){
    $('.classUserProfilclick').on('click', function(){
        var questionId = $(this).data('id');
        var questionText = $(this).data('question');
        
        // Update the question text display
        $('#questionText').text(questionText);
    });
});
</script>



</body>
</html>

